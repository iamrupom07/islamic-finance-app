import "dotenv/config";
import { defineConfig } from "prisma/config";
export default defineConfig({
  schema: "prisma/schema.prisma",
  migrations: { path: "prisma/migrations" },
  datasource: {
    url:
      process.env.DIRECT_URL ??
      "postgresql://unused:unused@localhost:5432/unused",
  },
});
